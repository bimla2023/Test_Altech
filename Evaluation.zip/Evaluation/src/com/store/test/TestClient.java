package com.store.test;

import com.store.Order;
import com.store.OrderServiceUtil;

public class TestClient {

	public static void main(String[] args) {

		OrderServiceUtil orderUtil = new OrderServiceUtil();
		
		Order order1 = new Order(1,"Customer1",500.2f,"CoD");
		Order order2 = new Order(2,"Customer2",400.2f,"Gift Card");
		Order order3 = new Order(3,"Customer3",325.2f,"Internet Banking");
		//adding the order
		orderUtil.addOrder(order1);
		orderUtil.addOrder(order2);
		orderUtil.addOrder(order3);
		
		
		

	}

}
