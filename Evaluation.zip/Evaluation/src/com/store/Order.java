package com.store;

public class Order implements Comparable<Order> {

	//Instance variables
	private int orderId;
	private String customerName;
	private float orderAmount;
	private String payementOption;
	
	//parametrized constructor with the above filed
	public Order(int orderId, String customerName, float orderAmount, String payementOption) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.orderAmount = orderAmount;
		this.payementOption = payementOption;
	}

	/**
	 * @return the orderId
	 */
	public int getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the orderAmount
	 */
	public float getOrderAmount() {
		return orderAmount;
	}

	/**
	 * @param orderAmount the orderAmount to set
	 * @throws InvalidOrderException 
	 */
	public void setOrderAmount(float orderAmount) throws InvalidOrderException{
		this.orderAmount = orderAmount;
		if(orderAmount >100 || orderAmount ==0) {
			System.out.println("Order Amount is Valid");
		}
		else if(orderAmount <100){
			throw new InvalidOrderException("OrdeAmount <100");
		}
		
		
	}

	/**
	 * @return the payementOption
	 */
	public String getPayementOption() {
		return payementOption;
	}


	public void setPayementOption(String payementOption) throws InvalidOrderException {
		this.payementOption = payementOption;
		if(payementOption == "CoD" || payementOption == "Gift Card" || payementOption == "Internet Banking") {
			System.out.println("Valid Payement Option");
		}
		else{
			throw new InvalidOrderException("InValid Payement Option");
		}
	}
	
	@Override
	public int compareTo(Order o) {
		
		return 0;
	}
	
	
	
	
	
}
