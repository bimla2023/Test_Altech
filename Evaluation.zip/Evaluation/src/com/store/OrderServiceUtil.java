package com.store;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class OrderServiceUtil {
	//Tree map
	private Map<Order,Integer> treeMap = new TreeMap<>();;
	Order order;
	
	static int ref = 0;
	//method to add an order
	public void addOrder(Order order) {
		
	
		treeMap.put(order, ref);
		ref = ref +1;
		System.out.println("Order is added " +this.order);
	}
	
	//method to search and return the order
	public Order searchOrder(String orderId) {
		//Iteration
		int id = Integer.parseInt(orderId);
		Set<Order> keyset = treeMap.keySet();
		Collection<Integer> values = treeMap.values();
		for (Order key : keyset) {
			System.out.println("key :" +key +" Orders :" +treeMap.get(keyset));
			
		}
		return order;
		
	}
	
	//compute and return total amount of all the order
	
	public float findTotal() {
		
		return 0;
	}
	

	
	
	

}
