package com.store;

public class InvalidOrderException extends Exception{
	public InvalidOrderException(String s) {
		super(s);
	}
}
