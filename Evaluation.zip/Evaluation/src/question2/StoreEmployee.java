package question2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class StoreEmployee {

	public static void main(String[] args) throws IOException {
		int emplid;
		String empName;
		int deptNo;
		File file=null;
		   if (0 < args.length) {
		          file = new File(args[0]);
		      }
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter Emplyee Id :");
		emplid = sc.nextInt();
		System.out.println(" Enter Emplyee Name :");
		empName = sc.next();
		System.out.println(" Enter Emplyee deptNo :");
		deptNo = sc.nextInt();
		

		Employee emp1 = new Employee(emplid,empName,deptNo);
		System.out.println("Enter Data for second employee :");
		System.out.println(" Enter Emplyee Id :");
		emplid = sc.nextInt();
		System.out.println(" Enter Emplyee Name :");
		empName = sc.next();
		System.out.println(" Enter Emplyee deptNo :");
		deptNo = sc.nextInt();

		Employee emp2 = new Employee(emplid,empName,deptNo);
		
	
		FileOutputStream fos= new FileOutputStream(file);
		ObjectOutputStream oos =new ObjectOutputStream(fos);
		
		
		try {
			if(!file.exists()) {
				file.createNewFile();
			}
			oos.writeObject(emp1);
			oos.writeObject(emp2);
			System.out.println("===Test is written ===");
			oos.close();
			fos.close();
			
		}catch(FileNotFoundException e ) {
			System.out.println("File not found");
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		FileInputStream fis= new FileInputStream(file);
		ObjectInputStream ios =new ObjectInputStream(fis);
		
		System.out.println("==Reading from a file ===");
		System.out.println(emp1.toString());
		System.out.println(emp2.toString());
		
		ios.close();
		fis.close();
		
	
		


	}

}
