package question2;

import java.io.Serializable;

public class Employee  implements Serializable{
	
	public int empId;
	public String empName;
	public int deptNo;
	
	
	
	public Employee(int empId, String empName, int deptNo) {
		
		this.empId = empId;
		this.empName = empName;
		this.deptNo = deptNo;
	}
	
	  @Override
	  public String toString() {
	  return "Name: " + empName + "EmpId : " +empId +"Dept No : " +deptNo;
	  }

	//Getter and setter methods
	public int getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}
	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	/**
	 * @return the deptNo
	 */
	public int getDeptNo() {
		return deptNo;
	}
	/**
	 * @param deptNo the deptNo to set
	 */
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	
	
	

}
